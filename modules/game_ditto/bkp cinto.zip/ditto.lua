local mainWindow = nil

function onCreatureHealthPercentChangeUPDATE(creature, health)
    if (creature:isLocalPlayerSummon()) then
	sendUpdateBelt()
    end
end

function onCreatureManaPercentChangeUPDATE(localPlayer, mana, maxMana)
	sendUpdateBelt()
end

function onFreeCapacityChangeUPDATE(player, freeCapacity)
	sendUpdateBelt()
end

config = {
  OPCODE_CINTO = {26, 27},
}

function init()  
  mainWindow = g_ui.loadUI('ditto', modules.game_interface.getLeftPanel())
  mainWindow:disableResize(true)
  
  Portrait1 = mainWindow:recursiveGetChildById("Portrait1")
  PortraitBackground1 = mainWindow:recursiveGetChildById("PortraitBackground1")
  PokemonRevive1 = mainWindow:recursiveGetChildById("PokemonRevive1")
  PokemonUse1 = mainWindow:recursiveGetChildById("PokemonUse1")
  PokemonName1 = mainWindow:recursiveGetChildById("PokemonName1")
  PokemonLevel1 = mainWindow:recursiveGetChildById("PokemonLevel1")
  PokemonHP1 = mainWindow:recursiveGetChildById("PokemonHP1")
  PokemonMP1 = mainWindow:recursiveGetChildById("PokemonMP1")
  PokemonEXP1 = mainWindow:recursiveGetChildById("PokemonEXP1")

  Portrait2 = mainWindow:recursiveGetChildById("Portrait2")
  PortraitBackground2 = mainWindow:recursiveGetChildById("PortraitBackground2")
  PokemonRevive2 = mainWindow:recursiveGetChildById("PokemonRevive2")
  PokemonUse2 = mainWindow:recursiveGetChildById("PokemonUse2")
  PokemonName2 = mainWindow:recursiveGetChildById("PokemonName2")
  PokemonLevel2 = mainWindow:recursiveGetChildById("PokemonLevel2")
  PokemonHP2 = mainWindow:recursiveGetChildById("PokemonHP2")
  PokemonMP2 = mainWindow:recursiveGetChildById("PokemonMP2")
  PokemonEXP2 = mainWindow:recursiveGetChildById("PokemonEXP2")

  Portrait3 = mainWindow:recursiveGetChildById("Portrait3")
  PortraitBackground3 = mainWindow:recursiveGetChildById("PortraitBackground3")
  PokemonRevive3 = mainWindow:recursiveGetChildById("PokemonRevive3")
  PokemonUse3 = mainWindow:recursiveGetChildById("PokemonUse3")
  PokemonName3 = mainWindow:recursiveGetChildById("PokemonName3")
  PokemonLevel3 = mainWindow:recursiveGetChildById("PokemonLevel3")
  PokemonHP3 = mainWindow:recursiveGetChildById("PokemonHP3")
  PokemonMP3 = mainWindow:recursiveGetChildById("PokemonMP3")
  PokemonEXP3 = mainWindow:recursiveGetChildById("PokemonEXP3")

  Portrait4 = mainWindow:recursiveGetChildById("Portrait4")
  PortraitBackground4 = mainWindow:recursiveGetChildById("PortraitBackground4")
  PokemonRevive4 = mainWindow:recursiveGetChildById("PokemonRevive4")
  PokemonUse4 = mainWindow:recursiveGetChildById("PokemonUse4")
  PokemonName4 = mainWindow:recursiveGetChildById("PokemonName4")
  PokemonLevel4 = mainWindow:recursiveGetChildById("PokemonLevel4")
  PokemonHP4 = mainWindow:recursiveGetChildById("PokemonHP4")
  PokemonMP4 = mainWindow:recursiveGetChildById("PokemonMP4")
  PokemonEXP4 = mainWindow:recursiveGetChildById("PokemonEXP4")

  Portrait5 = mainWindow:recursiveGetChildById("Portrait5")
  PortraitBackground5 = mainWindow:recursiveGetChildById("PortraitBackground5")
  PokemonRevive5 = mainWindow:recursiveGetChildById("PokemonRevive5")
  PokemonUse5 = mainWindow:recursiveGetChildById("PokemonUse5")
  PokemonName5 = mainWindow:recursiveGetChildById("PokemonName5")
  PokemonLevel5 = mainWindow:recursiveGetChildById("PokemonLevel5")
  PokemonHP5 = mainWindow:recursiveGetChildById("PokemonHP5")
  PokemonMP5 = mainWindow:recursiveGetChildById("PokemonMP5")
  PokemonEXP5 = mainWindow:recursiveGetChildById("PokemonEXP5")

  Portrait6 = mainWindow:recursiveGetChildById("Portrait6")
  PortraitBackground6 = mainWindow:recursiveGetChildById("PortraitBackground6")
  PokemonRevive6 = mainWindow:recursiveGetChildById("PokemonRevive6")
  PokemonUse6 = mainWindow:recursiveGetChildById("PokemonUse6")
  PokemonName6 = mainWindow:recursiveGetChildById("PokemonName6")
  PokemonLevel6 = mainWindow:recursiveGetChildById("PokemonLevel6")
  PokemonHP6 = mainWindow:recursiveGetChildById("PokemonHP6")
  PokemonMP6 = mainWindow:recursiveGetChildById("PokemonMP6")
  PokemonEXP6 = mainWindow:recursiveGetChildById("PokemonEXP6")  

  ProtocolGame.registerExtendedOpcode(config.OPCODE_CINTO[1], function(protocol, opcode, buffer) cinto(protocol, opcode, buffer) end)

  connect(g_game, {
	onGameStart = online,
    onGameEnd = hide
  })

    connect(Creature, {
        onHealthPercentChange = onCreatureHealthPercentChangeUPDATE,
    })
	
  connect(LocalPlayer, { onManaChange = onCreatureManaPercentChangeUPDATE,
                        onExperienceChange = onExperienceChangeUPDATE,
                        onFreeCapacityChange = onFreeCapacityChangeUPDATE,
						 })
  
  mainWindow:setup()
end

function terminate()
  disconnect(g_game, {
    onGameStart = refresh,
    onGameEnd = offline
  })

  disconnect(Creature, {
    onHealthPercentChange = onCreatureHealthPercentChangeUPDATE,
  })
  
  disconnect(LocalPlayer, { onManaChange = onCreatureManaPercentChangeUPDATE,
    onExperienceChange = onExperienceChangeUPDATE,
    onFreeCapacityChange = onFreeCapacityChangeUPDATE,
  })
  
  mainWindow:hide()
  ProtocolGame.unregisterExtendedOpcode(config.OPCODE_CINTO[1])
end

function getExpForLvl(lvl)
	return ( ( ( ( 50 * lvl ) - 150 ) * lvl ) + 400) * lvl / 3
end

function hidepokemon_1()
  Portrait1:hide()
  PortraitBackground1:hide()
  PokemonRevive1:hide()
  PokemonUse1:hide()
  PokemonName1:hide()
  PokemonLevel1:hide()
  PokemonHP1:hide()
  PokemonMP1:hide()
  PokemonEXP1:hide()
end

function showpokemon_1()
  Portrait1:show()
  PortraitBackground1:show()
  PokemonName1:show()
  PokemonLevel1:show()
  PokemonHP1:show()
  PokemonMP1:show()
  PokemonEXP1:show()
end

function hidepokemon_2()
  Portrait2:hide()
  PortraitBackground2:hide()
  PokemonRevive2:hide()
  PokemonUse2:hide()
  PokemonName2:hide()
  PokemonLevel2:hide()
  PokemonHP2:hide()
  PokemonMP2:hide()
  PokemonEXP2:hide()
end

function showpokemon_2()
  Portrait2:show()
  PortraitBackground2:show()
  PokemonName2:show()
  PokemonLevel2:show()
  PokemonHP2:show()
  PokemonMP2:show()
  PokemonEXP2:show()
end

function hidepokemon_3()
  Portrait3:hide()
  PortraitBackground3:hide()
  PokemonRevive3:hide()
  PokemonUse3:hide()
  PokemonName3:hide()
  PokemonLevel3:hide()
  PokemonHP3:hide()
  PokemonMP3:hide()
  PokemonEXP3:hide()
end

function showpokemon_3()
  Portrait3:show()
  PortraitBackground3:show()
  PokemonName3:show()
  PokemonLevel3:show()
  PokemonHP3:show()
  PokemonMP3:show()
  PokemonEXP3:show()
end

function hidepokemon_4()
  Portrait4:hide()
  PortraitBackground4:hide()
  PokemonRevive4:hide()
  PokemonUse4:hide()
  PokemonName4:hide()
  PokemonLevel4:hide()
  PokemonHP4:hide()
  PokemonMP4:hide()
  PokemonEXP4:hide()
end

function showpokemon_4()
  Portrait4:show()
  PortraitBackground4:show()
  PokemonName4:show()
  PokemonLevel4:show()
  PokemonHP4:show()
  PokemonMP4:show()
  PokemonEXP4:show()
end

function hidepokemon_5()
  Portrait5:hide()
  PortraitBackground5:hide()
  PokemonRevive5:hide()
  PokemonUse5:hide()
  PokemonName5:hide()
  PokemonLevel5:hide()
  PokemonHP5:hide()
  PokemonMP5:hide()
  PokemonEXP5:hide()
end

function showpokemon_5()
  Portrait5:show()
  PortraitBackground5:show()
  PokemonName5:show()
  PokemonLevel5:show()
  PokemonHP5:show()
  PokemonMP5:show()
  PokemonEXP5:show()
end

function hidepokemon_6()
  Portrait6:hide()
  PortraitBackground6:hide()
  PokemonRevive6:hide()
  PokemonUse6:hide()
  PokemonName6:hide()
  PokemonLevel6:hide()
  PokemonHP6:hide()
  PokemonMP6:hide()
  PokemonEXP6:hide()
end

function showpokemon_6()
  Portrait6:show()
  PortraitBackground6:show()
  PokemonName6:show()
  PokemonLevel6:show()
  PokemonHP6:show()
  PokemonMP6:show()
  PokemonEXP6:show()
end

function setPokemon_1(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_1()
else
showpokemon_1()
PokemonRevive1:hide()
PokemonUse1:hide()
    Portrait1:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName1:setText(NAME)
    PokemonLevel1:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP1:setValue(HP, 0, HPMAX)
    PokemonMP1:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP1:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground1:setBorderColor( "yellow" )
	   PokemonUse1:show()
    else
       PortraitBackground1:setBorderColor( "black" )
	   PokemonUse1:hide()
    end
	
     if STATUS == "off" then
	 PokemonName1:setOpacity(0.2)
	 PokemonLevel1:setOpacity(0.2)
	 PokemonHP1:hide()
	 PokemonMP1:hide()
	 PokemonEXP1:hide()
	 Portrait1:setOpacity(0.2)
	 PortraitBackground1:setOpacity(0.2)
	 Portrait1.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive1:show()
	       PokemonRevive1.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait1:setOpacity(1)
	 PortraitBackground1:setOpacity(1)
     Portrait1.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName1:setOpacity(1)
	 PokemonLevel1:setOpacity(1)
     end
end

end

function setPokemon_2(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_2()
else
showpokemon_2()
PokemonRevive2:hide()
PokemonUse2:hide()
    Portrait2:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName2:setText(NAME)
    PokemonLevel2:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP2:setValue(HP, 0, HPMAX)
    PokemonMP2:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP2:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground2:setBorderColor( "yellow" )
	   PokemonUse2:show()
    else
       PortraitBackground2:setBorderColor( "black" )
	   PokemonUse2:hide()
    end
	
     if STATUS == "off" then
	 PokemonName2:setOpacity(0.2)
	 PokemonLevel2:setOpacity(0.2)
	 PokemonHP2:hide()
	 PokemonMP2:hide()
	 PokemonEXP2:hide()
	 Portrait2:setOpacity(0.2)
	 PortraitBackground2:setOpacity(0.2)
	 Portrait2.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive2:show()
	       PokemonRevive2.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait2:setOpacity(1)
	 PortraitBackground2:setOpacity(1)
     Portrait2.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName2:setOpacity(1)
	 PokemonLevel2:setOpacity(1)
     end
end

end

function setPokemon_3(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_3()
else
showpokemon_3()
PokemonRevive3:hide()
PokemonUse3:hide()
    Portrait3:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName3:setText(NAME)
    PokemonLevel3:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP3:setValue(HP, 0, HPMAX)
    PokemonMP3:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP3:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground3:setBorderColor( "yellow" )
	   PokemonUse3:show()
    else
       PortraitBackground3:setBorderColor( "black" )
	   PokemonUse3:hide()
    end
	
     if STATUS == "off" then
	 PokemonName3:setOpacity(0.2)
	 PokemonLevel3:setOpacity(0.2)
	 PokemonHP3:hide()
	 PokemonMP3:hide()
	 PokemonEXP3:hide()
	 Portrait3:setOpacity(0.2)
	 PortraitBackground3:setOpacity(0.2)
	 Portrait3.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive3:show()
	       PokemonRevive3.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait3:setOpacity(1)
	 PortraitBackground3:setOpacity(1)
     Portrait3.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName3:setOpacity(1)
	 PokemonLevel3:setOpacity(1)
     end
end

end

function setPokemon_4(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_4()
else
showpokemon_4()
PokemonRevive4:hide()
PokemonUse4:hide()
    Portrait4:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName4:setText(NAME)
    PokemonLevel4:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP4:setValue(HP, 0, HPMAX)
    PokemonMP4:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP4:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground4:setBorderColor( "yellow" )
	   PokemonUse4:show()
    else
       PortraitBackground4:setBorderColor( "black" )
	   PokemonUse4:hide()
    end
	
     if STATUS == "off" then
	 PokemonName4:setOpacity(0.2)
	 PokemonLevel4:setOpacity(0.2)
	 PokemonHP4:hide()
	 PokemonMP4:hide()
	 PokemonEXP4:hide()
	 Portrait4:setOpacity(0.2)
	 PortraitBackground4:setOpacity(0.2)
	 Portrait4.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive4:show()
	       PokemonRevive4.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait4:setOpacity(1)
	 PortraitBackground4:setOpacity(1)
     Portrait4.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName4:setOpacity(1)
	 PokemonLevel4:setOpacity(1)
     end
end

end

function setPokemon_5(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_5()
else
showpokemon_5()
PokemonRevive5:hide()
PokemonUse5:hide()
    Portrait5:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName5:setText(NAME)
    PokemonLevel5:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP5:setValue(HP, 0, HPMAX)
    PokemonMP5:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP5:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground5:setBorderColor( "yellow" )
	   PokemonUse5:show()
    else
       PortraitBackground5:setBorderColor( "black" )
	   PokemonUse5:hide()
    end
	
     if STATUS == "off" then
	 PokemonName5:setOpacity(0.2)
	 PokemonLevel5:setOpacity(0.2)
	 PokemonHP5:hide()
	 PokemonMP5:hide()
	 PokemonEXP5:hide()
	 Portrait5:setOpacity(0.2)
	 PortraitBackground5:setOpacity(0.2)
	 Portrait5.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive5:show()
	       PokemonRevive5.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait5:setOpacity(1)
	 PortraitBackground5:setOpacity(1)
     Portrait5.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName5:setOpacity(1)
	 PokemonLevel5:setOpacity(1)
     end
end

end

function setPokemon_6(hide, FASTCALL, DEXNUMBER, NAME, STATUS, LEVEL, UPLEVEL, EXP, HPMAX, HP, ENERGY_MAX, ENERGY, revive)

if hide then
hidepokemon_6()
else
showpokemon_6()
PokemonRevive6:hide()
PokemonUse6:hide()
    Portrait6:setImageSource("/images/pictures/"..DEXNUMBER)
    PokemonName6:setText(NAME)
    PokemonLevel6:setText( "Lv. " .. LEVEL.."  ["..UPLEVEL.."]" )
    PokemonHP6:setValue(HP, 0, HPMAX)
    PokemonMP6:setValue(ENERGY, 0, ENERGY_MAX)
    PokemonEXP6:setValue(EXP - getExpForLvl(LEVEL - 1), 0, getExpForLvl(LEVEL) -  getExpForLvl(LEVEL - 1))
    
    if STATUS == "use" then
       PortraitBackground6:setBorderColor( "yellow" )
	   PokemonUse6:show()
    else
       PortraitBackground6:setBorderColor( "black" )
	   PokemonUse6:hide()
    end
	
     if STATUS == "off" then
	 PokemonName6:setOpacity(0.2)
	 PokemonLevel6:setOpacity(0.2)
	 PokemonHP6:hide()
	 PokemonMP6:hide()
	 PokemonEXP6:hide()
	 Portrait6:setOpacity(0.2)
	 PortraitBackground6:setOpacity(0.2)
	 Portrait6.onMouseRelease = function() sendBeltDeadMSG() end
	 
	 	if revive then
	       PokemonRevive6:show()
	       PokemonRevive6.onClick = function() sendReviveBelt( FASTCALL ) end
	    end
	 
	 else
	 Portrait6:setOpacity(1)
	 PortraitBackground6:setOpacity(1)
     Portrait6.onMouseRelease = function() g_game.talkChannel(MessageModes.Say, 0 , '/cp ' .. FASTCALL) end
	 PokemonName6:setOpacity(1)
	 PokemonLevel6:setOpacity(1)
     end
end

end

function spairs(t, order)
    -- collect the keys
    local keys = {}
    for k in pairs(t) do keys[#keys+1] = k end

    -- if order function given, sort by it by passing the table and keys a, b,
    -- otherwise just sort the keys 
    if order then
        table.sort(keys, function(a,b) return order(t, a, b) end)
    else
        table.sort(keys)
    end

    -- return the iterator function
    local i = 0
    return function()
        i = i + 1
        if keys[i] then
            return keys[i], t[keys[i]]
        end
    end
end

function cinto(protocol, opcode, buffer)
  if opcode == config.OPCODE_CINTO[1] then
    local blocks = buffer:explode("@")
	local revive = blocks[1] == '1'
	table.remove(blocks, 1)
	local onUse = false
	
	local poketable = {}
	
  for k,v in spairs(blocks, function(t,a,b) return t[a] < t[b] end) do
    table.insert(poketable, v)
  end

	local slot = false
	local openMoves = false
	
	if #poketable == 0 then
	mainWindow:setHeight(85)
	hidepokemon_1()
	hidepokemon_2()
	hidepokemon_3()
	hidepokemon_4()
	hidepokemon_5()
	hidepokemon_6()
	elseif #poketable == 1 then
	mainWindow:setHeight(85)
	hidepokemon_2()
	hidepokemon_3()
	hidepokemon_4()
	hidepokemon_5()
	hidepokemon_6()
	elseif #poketable == 2 then
	mainWindow:setHeight(140)
	hidepokemon_3()
	hidepokemon_4()
	hidepokemon_5()
	hidepokemon_6()
	elseif #poketable == 3 then
	mainWindow:setHeight(195)
	hidepokemon_4()
	hidepokemon_5()
	hidepokemon_6()
	elseif #poketable == 4 then
	mainWindow:setHeight(250)
	hidepokemon_5()
	hidepokemon_6()
	elseif #poketable == 5 then
	mainWindow:setHeight(305)
	hidepokemon_6()
	elseif #poketable == 6 then
	mainWindow:setHeight(360)
	end
	
	for index, data in ipairs( poketable ) do
	
	if index > 6 then break end
	
	local step1 = data:explode("|")

	local INFO_FASTCALL = step1[1]		
	local INFO_DEXNUMBER = step1[2]
	local INFO_NAME = step1[3]
	local INFO_STATUS = step1[4]
	local INFO_LEVEL = step1[5]
	local INFO_UPLEVEL = step1[6]
	local INFO_EXP = step1[7]
	
	local INFO_HPMAX = step1[8]
	local INFO_HP = step1[9]
	
	local INFO_ENERGY_MAX = step1[10]
	local INFO_ENERGY = step1[11]
	local INFO_SLOT = step1[12]
		
	local expForThisLVL = INFO_EXP - getExpForLvl(INFO_LEVEL - 1)
	local totalExpSingleLVL = getExpForLvl(INFO_LEVEL) -  getExpForLvl(INFO_LEVEL - 1)

		if INFO_SLOT == "on" then
		modules.game_playerstats.UPDATE_NAMEBAR(INFO_NAME)
		modules.game_playerstats.UPDATE_LEVELBAR("Lv. "..INFO_LEVEL.."  ["..INFO_UPLEVEL.."]")
		
		modules.game_playerstats.UPDATE_HPBAR( tonumber(INFO_HP), tonumber(INFO_HPMAX) )
		modules.game_playerstats.UPDATE_MPBAR( tonumber(INFO_ENERGY), tonumber(INFO_ENERGY_MAX) )
		modules.game_playerstats.UPDATE_EXPBAR( tonumber(expForThisLVL), tonumber(totalExpSingleLVL) )
		modules.game_playerstats.UPDATE_PORTRAIT( INFO_DEXNUMBER )
		slot = true		
		end
		
		if INFO_STATUS == "use" then
		openMoves = true
		modules.game_pokemoves.openMoves()		
		end
	
	    if index == 1 then
	       setPokemon_1(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    elseif index == 2 then	
	       setPokemon_2(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    elseif index == 3 then	
	       setPokemon_3(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    elseif index == 4 then	
	       setPokemon_4(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    elseif index == 5 then	
	       setPokemon_5(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    elseif index == 6 then	
	       setPokemon_6(false, INFO_FASTCALL, INFO_DEXNUMBER, INFO_NAME, INFO_STATUS, INFO_LEVEL, INFO_UPLEVEL, tonumber(INFO_EXP), tonumber(INFO_HPMAX), tonumber(INFO_HP), tonumber(INFO_ENERGY_MAX), tonumber(INFO_ENERGY), revive)
	    end
		
	end
	
	
if not slot then
   modules.game_playerstats.UPDATE_NAMEBAR( "?" )
   modules.game_playerstats.UPDATE_LEVELBAR( "-" )
   modules.game_playerstats.UPDATE_HPBAR( tonumber(0), tonumber(0) )
   modules.game_playerstats.UPDATE_MPBAR( tonumber(0), tonumber(0) )
   modules.game_playerstats.UPDATE_EXPBAR( tonumber(0), tonumber(0) )
   modules.game_playerstats.UPDATE_PORTRAIT( 0 )
end

if not openMoves then
   modules.game_pokemoves.closeMoves()
end
	
	mainWindow:raise()
	mainWindow:focus()
  end
end

function sendUpdateBelt()
	if g_game.isOnline() then 
		protocol = g_game.getProtocolGame()
		protocol:sendExtendedOpcode(config.OPCODE_CINTO[2], 'UPDATE')
	end
end

function sendBeltDeadMSG()
	if g_game.isOnline() then 
		protocol = g_game.getProtocolGame()
		protocol:sendExtendedOpcode(config.OPCODE_CINTO[2], 'DEAD')
	end
end

function sendReviveBelt( INFO_FASTCALL )
	if g_game.isOnline() then 
		protocol = g_game.getProtocolGame()
		protocol:sendExtendedOpcode(config.OPCODE_CINTO[2], tonumber( INFO_FASTCALL ))
	end
end

function online()
	mainWindow:setVisible(true)
end

function offline()
  mainWindow:setVisible(false)
end

function toggle()

if mainWindow:isVisible() then
mainWindow:setVisible(false)
else
mainWindow:setVisible(true)
end

end

function hide()
	if beltWindow then
		beltWindow:setVisible(false)
	end
end
